GRC 2026 — Social Media Kit
============================

Contents:
- grc-square-qualification-open.png (1080x1080, Instagram/LinkedIn square)
- grc-square-six-domains.png (1080x1080)
- grc-square-ambassador.png (1080x1080)

Usage: free to share on your own social channels to promote GRC participation,
ambassador recruitment, and teacher/school outreach. Sample graphics — swap in
real branding before wide distribution.
